/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalho01_restaurante.dados;

import java.util.Date;
import java.util.TreeSet;

/**
 *
 * @author ALEX e LUAN
 */
public class Cliente extends Pessoa{
    private int codCliente;

    public Cliente(int codCliente, String nome, String cpf, String dataNascimento, String telefone, Endereco endereco) {
        super(nome, cpf, dataNascimento, telefone, endereco);
        this.codCliente = codCliente;
    }

    @Override
    public String toString() {
        return super.toString() + ", Código Cliente: " + codCliente;
    }
}
