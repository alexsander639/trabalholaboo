/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trabalho01_restaurante.dados;

import java.io.Serializable;

/**
 *
 * @author ALEX e LUAN
 */
public class Endereco implements Serializable{
    private String cep;
    private String endereco;
    private int numero;
    private String uf;
    private String bairro;
    private String cidade;
    private String complemento;
    private String referencia;

    public Endereco(String cep, String endereco, int numero, String uf, String bairro, String cidade, String complemento, String referencia) {
        this.cep = cep;
        this.endereco = endereco;
        this.numero = numero;
        this.uf = uf;
        this.bairro = bairro;
        this.cidade = cidade;
        this.complemento = complemento;
        this.referencia = referencia;
    }

    public String getCep() {
        return cep;
    }

    public String getEndereco() {
        return endereco;
    }

    public int getNumero() {
        return numero;
    }

    public String getUf() {
        return uf;
    }
    
    public String getBairro() {
        return bairro;
    }

    public String getCidade() {
        return cidade;
    }

    public String getComplemento() {
        return complemento;
    }

    public String getReferencia() {
        return referencia;
    }

    @Override
    public String toString() {
        return ", Endereco{" + "cep=" + cep + ", endereco=" + endereco + ", numero=" + numero + ", uf=" + uf + ", bairro=" + bairro + ", cidade=" + cidade + ", complemento=" + complemento + ", referencia=" + referencia + '}';
    }
    
}
