/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalho01_restaurante.dados;

import java.util.Date;

/**
 *
 * @author ALEX e LUAN
 */
public class Administrador extends Funcionario{
    private String codSeguranca;

    public Administrador(String codSeguranca, int codFuncionario, String login, String senha, String nome, String cpf, String dataNascimento, String telefone, Endereco endereco) {
        super(codFuncionario, login, senha, nome, cpf, dataNascimento, telefone, endereco);
        this.codSeguranca = codSeguranca;
    }

    public String getCodSeguranca() {
        return codSeguranca;
    }

    public void setCodSeguranca(String codSeguranca) {
        this.codSeguranca = codSeguranca;
    }

    @Override
    public String toString() {
        return super.toString() + ", Administrador{" + "codSeguranca=" + codSeguranca + '}';
    }
    
}
