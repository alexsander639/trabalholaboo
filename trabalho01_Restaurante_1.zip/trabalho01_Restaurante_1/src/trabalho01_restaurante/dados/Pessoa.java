/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalho01_restaurante.dados;

import java.io.Serializable;
import java.util.UUID;

/**
 *
 * @author ALEX e LUAN
 */
public class Pessoa implements Comparable<Pessoa>, Serializable {
    private String id;
    private String nome;
    private String cpf;
    private String dataNascimento;
    private String telefone;
    private Endereco endereco;

    public Pessoa(String nome, String cpf, String dataNascimento, String telefone, Endereco endereco) {
        UUID uuid = UUID.randomUUID();
        this.id = uuid.toString();
        this.nome = nome;
        this.cpf = cpf;
        this.dataNascimento = dataNascimento;
        this.telefone = telefone;
        this.endereco = endereco;
    }

    public String getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public String getCpf() {
        return cpf;
    }

    public String getDataNascimento() {
        return dataNascimento;
    }

    public String getTelefone() {
        return telefone;
    }

    public Endereco getEndereco() {
        return endereco;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public void setDataNascimento(String dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public void setEndereco(Endereco endereco) {
        this.endereco = endereco;
    }
    
    @Override
    public int compareTo(Pessoa t) {
        return this.id.compareTo(t.getId());
    }

    @Override
    public String toString() {
        return "Nome: " + nome + ", cpf: " + cpf + ", dataNascimento: " + dataNascimento + ", telefone: " + telefone + ", endereco: " + endereco;
    }
}
