package trabalho01_restaurante.interfaces;

import trabalho01_restaurante.dados.Funcionario;

public interface IAtualizarFrame {

    abstract public void atualizarFrame(Funcionario funcionario);
    
}
