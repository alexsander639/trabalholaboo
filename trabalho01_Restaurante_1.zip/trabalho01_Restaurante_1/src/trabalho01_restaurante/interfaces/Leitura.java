package trabalho01_restaurante.interfaces;

import exception.ErroDeLeituraException;

public interface Leitura<T> {
    
    public abstract T lerDados(String path) throws ErroDeLeituraException;
    
}
